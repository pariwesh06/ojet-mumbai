
'use strict';
requirejs.config(
  {
    baseUrl: 'js',

    // Path mappings for the logical module names
    // Update the main-release-paths.json for release mode when updating the mappings
    paths:
    //injector:mainReleasePaths
    {
      'knockout': 'libs/knockout/knockout-3.4.2.debug',
      'jquery': 'libs/jquery/jquery-3.3.1',
      'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.12.1',
      'promise': 'libs/es6-promise/es6-promise',
      'hammerjs': 'libs/hammer/hammer-2.0.8',
      'ojdnd': 'libs/dnd-polyfill/dnd-polyfill-1.0.0',
      'ojs': 'libs/oj/v5.2.0/debug',
      'ojL10n': 'libs/oj/v5.2.0/ojL10n',
      'ojtranslations': 'libs/oj/v5.2.0/resources',
      'text': 'libs/require/text',
      'signals': 'libs/js-signals/signals',
      'customElements': 'libs/webcomponents/custom-elements.min',
      'proj4': 'libs/proj4js/dist/proj4-src',
      'css': 'libs/require-css/css'
    }
    //endinjector
    ,

    // Shim configurations for modules that do not expose AMD
    shim:
    {
      'jquery':
      {
        exports: ['jQuery', '$']
      }
    }
  }
);

require(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojarraydataprovider', 'ojs/ojknockout', 'ojs/ojinputtext', 'ojs/ojbutton', 'promise', 'ojs/ojtable'],
  function (oj, ko, $, ArrayDataProvider) {
    $(function () {
      function userformViewModel() {
        var self = this;
        self.rowRenderer = function (context) {
          var tableRow = context.rowContext.parentElement;
          var deptIdCell = $('<td>');
          var expandIconDiv =$('<div>');
          expandIconDiv.style.display = 'inline-block';
          expandIconDiv.style.width = '21px';
          var expandIcon = document.createElement('a');
          expandIcon.setAttribute('href', '#');
          expandIcon.setAttribute('aria-expanded', false);
          expandIconDiv.append(expandIcon);
          deptIdCell.append(expandIconDiv);
          
          tableRow.append(deptIdCell);
          console.log(tableRow);
        }
        self.add = function () {
          deptArray.push({
            DepartmentId: 500, DepartmentName: self.name()
          })
        }
        var table = $('#table');
        self.remove = function () {
          var currentRow = table[0].currentRow;
          if (currentRow != null) {
            deptArray.splice(currentRow['rowIndex'], 1);
          }
        }
        var deptArray = ko.observableArray([]);
        self.dataprovider = new ArrayDataProvider(deptArray, { keyAttributes: 'DepartmentId', implicitSort: [{ attribute: 'DepartmentId', direction: 'descending' }] });
        self.name = ko.observable('Ram');
        self.handleValueChanged = function () {
          var filter = document.getElementById('filter').rawValue;
          var filtered = deptArray().filter(function (track) {
            if (track.trackName) {
              var pattern = new RegExp(filter);
              var matches = pattern.exec(track.trackName);
              return matches ? matches.length : false;
            }
          });
          deptArray(filtered)
          console.log(filter);
        }
        this.search = function () {
          // console.log(self.name());
          // console.log(self.name('Oracle'))
          $.ajax('https://itunes.apple.com/search?term=' + self.name() + '&limit=5', {
            success: function (response) {
              var tracks = JSON.parse(response).results;
              deptArray(tracks);
            }
          })
        }
      }
      ko.applyBindings(new userformViewModel(), document.getElementById('div1'));
    });
  }
);
