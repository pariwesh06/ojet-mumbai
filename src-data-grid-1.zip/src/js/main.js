
'use strict';
requirejs.config(
  {
    baseUrl: 'js',

    // Path mappings for the logical module names
    // Update the main-release-paths.json for release mode when updating the mappings
    paths:
    //injector:mainReleasePaths
    {
      'knockout': 'libs/knockout/knockout-3.4.2.debug',
      'jquery': 'libs/jquery/jquery-3.3.1',
      'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.12.1',
      'promise': 'libs/es6-promise/es6-promise',
      'hammerjs': 'libs/hammer/hammer-2.0.8',
      'ojdnd': 'libs/dnd-polyfill/dnd-polyfill-1.0.0',
      'ojs': 'libs/oj/v5.2.0/debug',
      'ojL10n': 'libs/oj/v5.2.0/ojL10n',
      'ojtranslations': 'libs/oj/v5.2.0/resources',
      'text': 'libs/require/text',
      'signals': 'libs/js-signals/signals',
      'customElements': 'libs/webcomponents/custom-elements.min',
      'proj4': 'libs/proj4js/dist/proj4-src',
      'css': 'libs/require-css/css'
    }
    //endinjector
    ,

    // Shim configurations for modules that do not expose AMD
    shim:
    {
      'jquery':
      {
        exports: ['jQuery', '$']
      }
    }
  }
);
require(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojcollectiondatagriddatasource',
'ojs/ojdatagrid', 'ojs/ojknockout', 'ojs/ojinputtext', 'ojs/ojbutton', 'promise', 'ojs/ojtable', 'ojs/ojradioset', 'ojs/ojcheckboxset', 'ojs/ojselectcombobox'],
function (oj, ko, $, CollectionDataGridDataSource) {
  $(function () {
    function userformViewModel() {
        var base_url='http://localhost:3000/posts';
        var self = this;
        self.name = 'Ram';
        self.age = 20;
        self.gender = 'Female';
        self.skills = [];
        self.selectedRole = '';
        self.roles = ko.observableArray([{ value: "Manager", label: "Manager" }]);
        var collection = new oj.Collection(null, {
          url: 'http://localhost:3000/posts'
        });
        self.dataSource = new oj.CollectionDataGridDataSource(collection,
          { rowHeader: 'id' }
        );

        function init() {
          $.ajax('http://localhost:3000/comments', {
            success: function (response) {
              var roles = response.map(function (role) {
                return { value: role, label: role };
              })
              self.roles(roles);
            }
          })
        }
        init();
        self.update=function(event){
          //ajax
          console.log(event.detail.originalEvent.target.value)
          $.ajax(base_url+'/'+event.detail.cellContext.keys.row,{
            method:'patch',
            data:{
              name:event.detail.originalEvent.target.value
            }
          })
        }
        self.getCellTemplate = function (cellContext) {
          var mode = cellContext['mode'];
          if (mode === 'edit') {
            return oj.KnockoutTemplateUtils.getRenderer('edit')(cellContext);
          }
          else if (mode === 'navigation') {
            return oj.KnockoutTemplateUtils.getRenderer('readOnly')(cellContext);
          }
        }
        this.add = function () {

          $.ajax(base_url, {
            method: 'POST',
            success: function (response) {
              collection.add(response)
            },
            data: {
              name: self.name,
              age: self.age,
              gender: self.gender,
              skills: self.skills,
              role: self.selectedRole
            }
          })
        }
      }

      ko.applyBindings(new userformViewModel(), document.getElementById('div1'));
    });
  }
);
